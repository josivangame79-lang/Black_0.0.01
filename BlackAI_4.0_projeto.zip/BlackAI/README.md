# BLACK AI 4.0

Assistente Android híbrido: IA **local** (MediaPipe LLM, offline) + **BLACK CLOUD** (servidor próprio com modelos abertos via Ollama).
Código-fonte completo, **ainda sem APK compilado** (veja "Estado honesto" em RELATORIO_TESTES.md).

## Estrutura
- `app/` — app Android (Kotlin + Jetpack Compose, 10 telas)
- `server/` — backend Node.js 20+ sem dependências (`npm start`, `npm test`)
- `deploy/` — Docker Compose + Caddy (HTTPS)
- `.github/workflows/build-apk.yml` — compila o APK na nuvem

## 1. Obter o APK (3 caminhos)
**A) Android Studio (mais simples):** abra a pasta `BlackAI`, aguarde o sync do Gradle, `Build > Build APK(s)`. Saída: `app/build/outputs/apk/debug/app-debug.apk`.
**B) GitHub Actions (sem instalar nada):** suba a pasta para um repositório seu → aba *Actions* → *build-apk* → *Run workflow* → baixe o artefato `BlackAI-debug-apk`.
**C) Linha de comando:** JDK 17 + Android SDK (`ANDROID_HOME`) + Gradle 8.9 → `gradle assembleDebug`.
Instale no celular: copie o `.apk`, permita "instalar de fontes desconhecidas" e abra. (APK debug é assinado com a chave de debug — serve para testes.)
Se o Gradle reclamar de alguma versão de dependência, me envie o log: o código nunca foi compilado por mim (sem SDK no meu ambiente).

## 2. Servidor (BLACK CLOUD)
```bash
cd server && cp .env.example .env
openssl rand -hex 32        # cole em BLACK_TOKEN no .env
# Modelos abertos: instale o Ollama (ollama.com) e rode:
ollama pull qwen2.5:7b-instruct && ollama pull qwen2.5vl:7b
npm start
```
HTTPS é obrigatório no celular (HTTP só no emulador via `10.0.2.2`). Opções: `deploy/docker-compose.yml` com Caddy e um domínio, ou Tailscale/Cloudflare Tunnel apontando para a porta 3000.
No app: **Conectividade** → URL `https://...` + o `BLACK_TOKEN` → *Testar*.
Pesquisa web: defina `SEARXNG_URL` (recomendado, self-hosted) ou `BRAVE_SEARCH_API_KEY`.
Sandbox de código (`/dev/exec`) e compilação (`/dev/build-apk`) exigem **Docker** no servidor; `BUILD_IMAGE` deve ser uma imagem sua com Android SDK + Gradle e dependências em cache (execução sem rede).
⚠️ Montar `/var/run/docker.sock` dá ao container controle do Docker do host. Use apenas em servidor dedicado; alternativa mais segura: rodar `node server.js` direto no host.

## 3. Modelo local (offline)
Tela **Modelos de IA**. O motor é o MediaPipe LLM Inference e espera arquivos `.task`/`.bin` quantizados.
Sugestões de família (confira licença e baixe você mesmo — não verifiquei as URLs do seu lado): Qwen2.5 0.5B/1.5B/3B Instruct (Apache-2.0 nos menores; verifique cada tamanho) e Gemma (licença própria do Google, não é "open source" no sentido OSI). Procure por versões `.task` no Hugging Face (organização `litert-community`).
Escolha pelo tamanho: o app mostra RAM, espaço livre e uma estimativa de compatibilidade antes de instalar. Use *Importar arquivo* se baixar pelo PC.
Reconhecimento de voz: usa o reconhecedor do Android com preferência offline (precisa do pacote de idioma offline instalado). Whisper.cpp **não** está integrado. TTS: engine do Android.

## 4. Uso rápido
- Conversa: modo Auto/Local/Nuvem. "lembre-se que ..." grava na memória local, offline.
- Arquivos: escolha a pasta; o BLACK só acessa ela; cada gravação cria backup em `.black_backups`.
- Autonomia: dê um objetivo; o agente planeja, executa etapa a etapa, registra tudo. Gravar arquivos só se você ligar a opção. Com "comando de teste" definido, reverte se o teste falhar.
- Sync: automática só por Wi-Fi, fila local, servidor confirma (ack), conflitos preservados.
