// Teste de integração: sobe um "provedor de IA" falso e o servidor, e exercita as rotas.
import http from "node:http";
import { spawn } from "node:child_process";
import assert from "node:assert/strict";
import fs from "node:fs";
const mock = http.createServer((req, res) => {
  let b = ""; req.on("data", c => b += c); req.on("end", () => {
    const j = JSON.parse(b); res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify({ choices: [{ message: { content: "eco:" + j.model + ":" + j.messages.at(-1).content } }] }));
  });
}).listen(4999);
const data = "/tmp/black-test-" + Date.now();
const srv = spawn("node", ["server.js"], { env: { ...process.env, PORT: "4998", BLACK_TOKEN: "x".repeat(32), AI_BASE_URL: "http://localhost:4999/v1", DATA_DIR: data } });
await new Promise(r => setTimeout(r, 800));
const call = async (m, p, body, tok = "x".repeat(32)) => {
  const r = await fetch("http://localhost:4998" + p, { method: m, headers: { "Content-Type": "application/json", ...(tok ? { Authorization: "Bearer " + tok } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { s: r.status, j: await r.json() };
};
const results = [];
const t = async (n, f) => { try { await f(); results.push(["OK ", n]); } catch (e) { results.push(["FALHA", n + " -> " + e.message]); } };
await t("health sem token", async () => assert.equal((await call("GET", "/health", null, "")).s, 200));
await t("rota protegida sem token = 401", async () => assert.equal((await call("POST", "/chat", { message: "oi" }, "")).s, 401));
await t("token errado = 401", async () => assert.equal((await call("POST", "/chat", { message: "oi" }, "y".repeat(32))).s, 401));
await t("chat texto", async () => { const r = await call("POST", "/chat", { message: "oi" }); assert.equal(r.s, 200); assert.match(r.j.reply, /^eco:qwen/); });
await t("chat imagem usa modelo de visão", async () => { const r = await call("POST", "/chat", { message: "x", imageBase64: "AAAA" }); assert.match(r.j.reply, /^eco:qwen2.5vl/); });
await t("chat vazio = 400", async () => assert.equal((await call("POST", "/chat", {})).s, 400));
await t("sync push/pull", async () => {
  const a = await call("POST", "/sync/push", { device: "d1", items: [{ id: "m1", hash: "h1", baseHash: "", data: "a" }] });
  assert.equal(a.j.ack[0].status, "stored");
  const p = await call("POST", "/sync/pull", { device: "d1", since: 0 }); assert.equal(p.j.items.length, 1);
});
await t("sync conflito preserva cópia", async () => {
  const a = await call("POST", "/sync/push", { device: "d1", items: [{ id: "m1", hash: "h2", baseHash: "outro", data: "b" }] });
  assert.equal(a.j.ack[0].status, "conflict-preserved");
  assert.ok(fs.readdirSync(data + "/sync/d1").some(f => f.includes(".conflict-")));
});
await t("sync bloqueia path traversal no id", async () => { const a = await call("POST", "/sync/push", { device: "../../etc", items: [{ id: "../x", hash: "1" }] }); assert.equal(a.s, 200); assert.ok(!fs.existsSync("/tmp/x.json")); });
await t("dev/exec rejeita caminho fora do sandbox", async () => { const r = await call("POST", "/dev/exec", { files: { "../fora.txt": "x" }, command: "true" }); assert.equal(r.s, 500); assert.match(r.j.error, /inválido/); });
await t("dev/exec sem Docker responde erro claro", async () => { const r = await call("POST", "/dev/exec", { files: { "a.js": "1" }, command: "node a.js" }); assert.ok(r.s === 500 && /Docker/.test(r.j.error) || r.s === 200); });
await t("build-apk sem BUILD_IMAGE = 503", async () => assert.equal((await call("POST", "/dev/build-apk", { files: {} })).s, 503));
await t("search sem provedor = 503", async () => assert.equal((await call("POST", "/search", { query: "x" })).s, 503));
await t("activity log registra eventos", async () => assert.ok((await call("GET", "/activity")).j.lines.length > 0));
srv.kill(); mock.close();
for (const r of results) console.log(r.join(" "));
process.exit(results.some(r => r[0] === "FALHA") ? 1 : 0);
