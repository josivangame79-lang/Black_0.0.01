// BLACK CLOUD 4.0 — backend sem dependências externas (Node 20+).
// Modelos abertos via qualquer endpoint compatível com OpenAI (Ollama, llama.cpp server, vLLM).
import http from "node:http";
import https from "node:https";
import fs from "node:fs/promises";
import { existsSync, readFileSync } from "node:fs";
import crypto from "node:crypto";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";

const __dir = path.dirname(fileURLToPath(import.meta.url));

const envFile = path.join(__dir, ".env");
if (existsSync(envFile)) {
  for (const l of readFileSync(envFile, "utf8").split("\n")) {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
  }
}
const CFG = {
  port: Number(process.env.PORT || 3000),
  token: process.env.BLACK_TOKEN || "",
  aiBase: (process.env.AI_BASE_URL || "http://localhost:11434/v1").replace(/\/$/, ""),
  aiKey: process.env.AI_API_KEY || "ollama",
  model: process.env.AI_MODEL || "qwen2.5:7b-instruct",
  visionModel: process.env.AI_VISION_MODEL || "qwen2.5vl:7b",
  searxng: process.env.SEARXNG_URL || "",
  brave: process.env.BRAVE_SEARCH_API_KEY || "",
  dataDir: process.env.DATA_DIR || path.join(__dir, "data"),
  sandboxImage: process.env.SANDBOX_IMAGE || "node:22-slim",
  buildImage: process.env.BUILD_IMAGE || "",
};
if (!CFG.token || CFG.token.length < 24) {
  console.error("Defina BLACK_TOKEN no .env com pelo menos 24 caracteres (ex.: openssl rand -hex 32).");
  process.exit(1);
}

const log = async (event, extra = {}) => {
  await fs.mkdir(CFG.dataDir, { recursive: true });
  await fs.appendFile(path.join(CFG.dataDir, "activity.log"),
    JSON.stringify({ ts: new Date().toISOString(), event, ...extra }) + "\n");
};

const send = (res, code, obj) => {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(body) });
  res.end(body);
};
const readBody = (req, limit = 20 * 1024 * 1024) => new Promise((ok, bad) => {
  let size = 0; const chunks = [];
  req.on("data", c => { size += c.length; if (size > limit) { bad(new Error("payload grande demais")); req.destroy(); } else chunks.push(c); });
  req.on("end", () => { try { ok(chunks.length ? JSON.parse(Buffer.concat(chunks).toString("utf8")) : {}); } catch { bad(new Error("JSON inválido")); } });
  req.on("error", bad);
});
const authed = req => {
  const h = req.headers.authorization || "";
  const t = h.startsWith("Bearer ") ? h.slice(7) : "";
  const a = Buffer.from(t), b = Buffer.from(CFG.token);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};

const hits = new Map();
const limited = ip => {
  const now = Date.now(), w = (hits.get(ip) || []).filter(t => now - t < 60_000);
  w.push(now); hits.set(ip, w); return w.length > 120;
};

async function llm(messages, { vision = false, temperature = 0.6 } = {}) {
  const r = await fetch(`${CFG.aiBase}/chat/completions`, {
    method: "POST",
    headers: { Authorization: `Bearer ${CFG.aiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify({ model: vision ? CFG.visionModel : CFG.model, messages, temperature, stream: false }),
    signal: AbortSignal.timeout(180_000),
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error?.message || `Provedor de IA respondeu ${r.status}`);
  return d.choices?.[0]?.message?.content ?? "";
}

async function webSearch(q) {
  if (CFG.searxng) {
    const r = await fetch(`${CFG.searxng}/search?format=json&q=${encodeURIComponent(q)}`, { signal: AbortSignal.timeout(15000) });
    const d = await r.json();
    return (d.results || []).slice(0, 5).map(x => ({ title: x.title, url: x.url, description: x.content }));
  }
  if (CFG.brave) {
    const r = await fetch(`https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(q)}`,
      { headers: { "X-Subscription-Token": CFG.brave, Accept: "application/json" }, signal: AbortSignal.timeout(15000) });
    const d = await r.json();
    return (d.web?.results || []).slice(0, 5).map(x => ({ title: x.title, url: x.url, description: x.description }));
  }
  throw Object.assign(new Error("Configure SEARXNG_URL ou BRAVE_SEARCH_API_KEY."), { code: 503 });
}

// Sandbox Docker: sem rede, limites de CPU/RAM/processos/tempo, sem privilégios.
function sandbox(files, command, { timeoutMs = 60_000, image = CFG.sandboxImage } = {}) {
  return new Promise(async (ok, bad) => {
    const dir = path.join(CFG.dataDir, "sandbox", crypto.randomUUID());
    await fs.mkdir(dir, { recursive: true });
    try {
      for (const [name, content] of Object.entries(files || {})) {
        const target = path.resolve(dir, name);
        if (!target.startsWith(dir + path.sep)) throw new Error("caminho inválido: " + name);
        await fs.mkdir(path.dirname(target), { recursive: true });
        await fs.writeFile(target, String(content));
      }
    } catch (e) { await fs.rm(dir, { recursive: true, force: true }); return bad(e); }
    const args = ["run", "--rm", "--network", "none", "--memory", "512m", "--cpus", "1", "--pids-limit", "128",
      "--cap-drop", "ALL", "--security-opt", "no-new-privileges", "-v", `${dir}:/work`, "-w", "/work", image, "sh", "-c", command];
    const p = spawn("docker", args);
    let out = "", err = "", done = false;
    const finish = async fn => { if (done) return; done = true; clearTimeout(timer); await fs.rm(dir, { recursive: true, force: true }); fn(); };
    const timer = setTimeout(() => p.kill("SIGKILL"), timeoutMs);
    p.stdout.on("data", d => out = (out + d).slice(-20000));
    p.stderr.on("data", d => err = (err + d).slice(-20000));
    p.on("error", e => finish(() => bad(new Error("Docker indisponível: " + e.message))));
    p.on("close", code => finish(() => ok({ exitCode: code, stdout: out, stderr: err })));
  });
}

// Sincronização: nunca sobrescreve silenciosamente; conflitos geram cópia preservada.
const safeId = s => String(s || "").replace(/[^a-zA-Z0-9_-]/g, "").slice(0, 64);
async function syncPush(device, items) {
  const dir = path.join(CFG.dataDir, "sync", safeId(device) || "default");
  await fs.mkdir(dir, { recursive: true });
  const ack = [];
  for (const it of items) {
    const key = safeId(it.id); if (!key) continue;
    const file = path.join(dir, key + ".json");
    let status = "stored";
    if (existsSync(file)) {
      const cur = JSON.parse(await fs.readFile(file, "utf8"));
      if (cur.hash && cur.hash !== it.baseHash && cur.hash !== it.hash) {
        await fs.writeFile(path.join(dir, `${key}.conflict-${Date.now()}.bak`), JSON.stringify(cur));
        status = "conflict-preserved";
      }
    }
    await fs.writeFile(file, JSON.stringify({ ...it, serverTs: Date.now() }));
    ack.push({ id: key, status });
  }
  await log("sync.push", { device, count: ack.length });
  return ack;
}
async function syncPull(device, since) {
  const dir = path.join(CFG.dataDir, "sync", safeId(device) || "default");
  if (!existsSync(dir)) return [];
  const out = [];
  for (const f of await fs.readdir(dir)) {
    if (!f.endsWith(".json")) continue;
    const it = JSON.parse(await fs.readFile(path.join(dir, f), "utf8"));
    if ((it.serverTs || 0) > since) out.push(it);
  }
  return out;
}

const SYSTEM = "Você é BLACK, assistente pessoal inteligente. Responda em português do Brasil, com clareza. " +
  "Não afirme ter executado ações que você não executou. Operações sensíveis exigem autorização do usuário no aplicativo.";

const routes = {
  "GET /health": async () => [200, { ok: true, name: "BLACK CLOUD", version: "4.0", model: CFG.model }],

  "POST /chat": async (_req, b) => {
    const { messages = [], message = "", imageBase64 } = b;
    const hist = Array.isArray(messages) ? messages.slice(-30) : [];
    if (!message && !imageBase64 && !hist.length) return [400, { error: "Envie uma mensagem." }];
    const all = [{ role: "system", content: b.system || SYSTEM }, ...hist];
    if (message || imageBase64) {
      let content = message || "Analise a imagem enviada.";
      if (imageBase64) content = [{ type: "text", text: content }, { type: "image_url", image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }];
      all.push({ role: "user", content });
    }
    const reply = await llm(all, { vision: !!imageBase64 });
    await log("chat", { vision: !!imageBase64 });
    return [200, { reply }];
  },

  "POST /search": async (_req, b) => {
    const q = String(b.query || "").trim();
    if (!q) return [400, { error: "Informe a pesquisa." }];
    return [200, { results: await webSearch(q) }];
  },

  "POST /sync/push": async (_req, b) => [200, { ack: await syncPush(b.device, Array.isArray(b.items) ? b.items : []) }],
  "POST /sync/pull": async (_req, b) => [200, { items: await syncPull(b.device, Number(b.since || 0)) }],

  "POST /dev/exec": async (_req, b) => {
    const r = await sandbox(b.files, String(b.command || ""), { timeoutMs: Math.min(Number(b.timeoutMs || 60000), 300000) });
    await log("dev.exec", { exitCode: r.exitCode });
    return [200, r];
  },

  "POST /dev/build-apk": async (_req, b) => {
    if (!CFG.buildImage) return [503, { error: "Defina BUILD_IMAGE (imagem Docker com Android SDK + Gradle) no .env." }];
    const r = await sandbox(b.files, "gradle --offline assembleDebug --no-daemon", { timeoutMs: 900_000, image: CFG.buildImage });
    await log("dev.build", { exitCode: r.exitCode });
    return [200, r];
  },

  "GET /activity": async () => {
    const f = path.join(CFG.dataDir, "activity.log");
    const txt = existsSync(f) ? await fs.readFile(f, "utf8") : "";
    return [200, { lines: txt.trim().split("\n").filter(Boolean).slice(-200).map(l => JSON.parse(l)) }];
  },
};

const handler = async (req, res) => {
  try {
    const url = new URL(req.url, "http://x");
    const key = `${req.method} ${url.pathname}`;
    const route = routes[key];
    if (!route) return send(res, 404, { error: "não encontrado" });
    const ip = req.socket.remoteAddress || "?";
    if (limited(ip)) return send(res, 429, { error: "muitas requisições" });
    if (key !== "GET /health" && !authed(req)) { await log("auth.fail", { ip }); return send(res, 401, { error: "não autorizado" }); }
    const body = req.method === "POST" ? await readBody(req) : {};
    const [code, obj] = await route(req, body);
    send(res, code, obj);
  } catch (e) {
    console.error(e);
    send(res, e.code === 503 ? 503 : 500, { error: e.message || "erro interno" });
  }
};

if (process.env.TLS_KEY && process.env.TLS_CERT) {
  https.createServer({ key: readFileSync(process.env.TLS_KEY), cert: readFileSync(process.env.TLS_CERT) }, handler)
    .listen(CFG.port, "0.0.0.0", () => console.log(`BLACK CLOUD (HTTPS) na porta ${CFG.port}`));
} else {
  http.createServer(handler).listen(CFG.port, "0.0.0.0",
    () => console.log(`BLACK CLOUD (HTTP) na porta ${CFG.port} — em produção use proxy HTTPS ou TLS_KEY/TLS_CERT`));
}
