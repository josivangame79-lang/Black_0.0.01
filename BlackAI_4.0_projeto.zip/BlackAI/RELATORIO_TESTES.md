# Relatório de testes — BLACK AI 4.0

## Estado honesto
O ambiente onde trabalhei **não tem Android SDK, Gradle nem internet**. Portanto: **nenhum APK foi gerado** e **o código Kotlin nunca foi compilado nem executado**. Só o backend foi executado e testado de verdade.
Escrevi o código com cuidado (verifiquei apenas balanceamento de chaves/parênteses), mas é esperado que o primeiro build no Android Studio mostre alguns erros de compilação/versão de biblioteca para corrigirmos.

## Backend (executado: `cd server && npm test`) — 14/14 passaram
health sem token • 401 sem token • 401 token errado • chat texto • chat com imagem usa modelo de visão • chat vazio = 400 • sync push/pull • sync com conflito preserva cópia • id com path traversal neutralizado • sandbox rejeita caminho fora da pasta • sandbox sem Docker devolve erro claro • build-apk sem BUILD_IMAGE = 503 • search sem provedor = 503 • log de atividade.
NÃO testado: IA real (usei um provedor falso), Docker/sandbox real, pesquisa web real, TLS, compilação de APK no servidor.

## App Android — todos pendentes de teste em aparelho
| Requisito | Código escrito | Testado |
|---|---|---|
| Compilar projeto / Gradle | — | ❌ não rodou |
| Inicialização / 10 telas | sim | ❌ |
| Conversa offline (MediaPipe) | sim | ❌ |
| Conversa online (servidor) | sim (backend testado c/ mock) | ❌ no app |
| Roteamento auto/manual + fallback | sim | ❌ |
| Voz → texto (reconhecedor Android, preferência offline) | sim | ❌ |
| Texto → voz (TTS Android) | sim | ❌ |
| Análise de imagem | só via servidor (modelo de visão) | ❌ |
| Memória local (CRUD, busca, categorias, "lembre-se") | sim | ❌ |
| Arquivos (SAF, backup, versões, comparar, restaurar) | sim | ❌ |
| Fila + sync só Wi-Fi + ack + conflitos | sim | ❌ (servidor ✅) |
| Agente (plano, execução, retomar, log, teste+reversão) | sim | ❌ |
| Gerenciador de modelos (download Wi-Fi, importar, RAM/espaço) | sim | ❌ |
| Consumo de memória | — | ❌ |

## Não implementado (por honestidade)
- Modelo multimodal **local** (imagens só pelo servidor).
- Whisper.cpp / TTS neural offline (usei os recursos do Android).
- llama.cpp via JNI/NDK (usei MediaPipe LLM, que é mais simples de integrar).
- Sincronização de arquivos do servidor de volta para o celular (celular→servidor funciona; servidor→celular só para memórias).
- Autoedição dos próprios módulos do app pelo agente, e compilação automática de APK pelo servidor (endpoint existe, mas depende de você montar a imagem Docker com SDK).
- Lista de modelos com URLs verificadas; assinatura release; testes automatizados do Android.
