package com.blackassistant.app

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import java.security.MessageDigest
import java.util.UUID

data class Mem(val id: String, val category: String, val content: String, val updated: Long)
data class ChatMsg(val id: Long, val role: String, val text: String, val via: String, val ts: Long)
data class TaskItem(val id: String, val kind: String, val goal: String, val title: String, val status: String, val result: String, val idx: Int, val updated: Long)
data class Act(val ts: Long, val text: String)
data class QItem(val rowId: Long, val itemId: String, val kind: String, val payload: String, val hash: String, val baseHash: String)

fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/** Banco local (SQLite). Tudo é gravado AQUI primeiro; a fila "queue" alimenta a sincronização por Wi-Fi. */
class Db private constructor(private val ctx: Context) : SQLiteOpenHelper(ctx, "black.db", null, 1) {
    companion object {
        @Volatile private var inst: Db? = null
        fun get(ctx: Context): Db = inst ?: synchronized(this) { inst ?: Db(ctx.applicationContext).also { inst = it } }
    }

    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE memory(id TEXT PRIMARY KEY, category TEXT, content TEXT, updated INTEGER, deleted INTEGER DEFAULT 0)")
        d.execSQL("CREATE TABLE chat(id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, text TEXT, via TEXT, ts INTEGER)")
        d.execSQL("CREATE TABLE task(id TEXT PRIMARY KEY, kind TEXT, goal TEXT, title TEXT, status TEXT, result TEXT, idx INTEGER, updated INTEGER)")
        d.execSQL("CREATE TABLE activity(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, text TEXT)")
        d.execSQL("CREATE TABLE queue(id INTEGER PRIMARY KEY AUTOINCREMENT, itemId TEXT, kind TEXT, payload TEXT, hash TEXT, baseHash TEXT, ts INTEGER)")
        d.execSQL("CREATE TABLE synced(itemId TEXT PRIMARY KEY, hash TEXT)")
    }
    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {}

    private fun now() = System.currentTimeMillis()

    // ---------- Memória ----------
    fun saveMemory(category: String, content: String, id: String = UUID.randomUUID().toString()): String {
        val t = now()
        val cv = ContentValues().apply { put("id", id); put("category", category); put("content", content); put("updated", t); put("deleted", 0) }
        writableDatabase.insertWithOnConflict("memory", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
        enqueue("memory-$id", "memory", JSONObject().put("id", id).put("category", category).put("content", content).put("updated", t).put("deleted", false).toString())
        log("Memória salva [$category]: ${content.take(50)}")
        return id
    }
    fun deleteMemory(id: String) {
        val m = memory(id) ?: return
        val t = now()
        writableDatabase.execSQL("UPDATE memory SET deleted=1, updated=? WHERE id=?", arrayOf<Any>(t, id))
        enqueue("memory-$id", "memory", JSONObject().put("id", id).put("category", m.category).put("content", "").put("updated", t).put("deleted", true).toString())
        log("Memória excluída: ${m.content.take(40)}")
    }
    fun memory(id: String): Mem? = readableDatabase.rawQuery("SELECT id,category,content,updated FROM memory WHERE id=?", arrayOf(id)).use {
        if (it.moveToFirst()) Mem(it.getString(0), it.getString(1), it.getString(2), it.getLong(3)) else null
    }
    fun memories(query: String = "", category: String? = null): List<Mem> {
        val args = ArrayList<String>(); var where = "deleted=0"
        if (query.isNotBlank()) { where += " AND (content LIKE ? OR category LIKE ?)"; args += "%$query%"; args += "%$query%" }
        if (category != null) { where += " AND category=?"; args += category }
        val out = ArrayList<Mem>()
        readableDatabase.rawQuery("SELECT id,category,content,updated FROM memory WHERE $where ORDER BY updated DESC", args.toTypedArray()).use {
            while (it.moveToNext()) out += Mem(it.getString(0), it.getString(1), it.getString(2), it.getLong(3))
        }
        return out
    }
    fun categories(): List<String> = readableDatabase.rawQuery("SELECT DISTINCT category FROM memory WHERE deleted=0 ORDER BY category", null).use {
        val l = ArrayList<String>(); while (it.moveToNext()) l += it.getString(0); l
    }
    /** Recupera memórias relevantes para uma pergunta (busca por palavras). */
    fun relevantMemories(text: String, limit: Int = 6): List<Mem> {
        val words = text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length >= 4 }.distinct().take(8)
        val all = memories()
        if (words.isEmpty()) return all.take(3)
        return all.map { m -> m to words.count { w -> m.content.lowercase().contains(w) || m.category.lowercase().contains(w) } }
            .filter { it.second > 0 }.sortedByDescending { it.second }.take(limit).map { it.first }
    }

    // ---------- Chat ----------
    fun addChat(role: String, text: String, via: String = ""): Long {
        val cv = ContentValues().apply { put("role", role); put("text", text); put("via", via); put("ts", now()) }
        return writableDatabase.insert("chat", null, cv)
    }
    fun chat(limit: Int = 200): List<ChatMsg> {
        val out = ArrayList<ChatMsg>()
        readableDatabase.rawQuery("SELECT id,role,text,via,ts FROM chat ORDER BY id DESC LIMIT $limit", null).use {
            while (it.moveToNext()) out += ChatMsg(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getLong(4))
        }
        return out.reversed()
    }
    fun clearChat() { writableDatabase.execSQL("DELETE FROM chat") }

    // ---------- Tarefas ----------
    fun addTask(kind: String, goal: String, title: String, status: String = "pendente", idx: Int = 0): String {
        val id = UUID.randomUUID().toString()
        val cv = ContentValues().apply { put("id", id); put("kind", kind); put("goal", goal); put("title", title); put("status", status); put("result", ""); put("idx", idx); put("updated", now()) }
        writableDatabase.insert("task", null, cv)
        enqueue("task-$id", "task", JSONObject().put("id", id).put("kind", kind).put("goal", goal).put("title", title).put("status", status).toString())
        return id
    }
    fun updateTask(id: String, status: String, result: String? = null) {
        val cv = ContentValues().apply { put("status", status); if (result != null) put("result", result); put("updated", now()) }
        writableDatabase.update("task", cv, "id=?", arrayOf(id))
    }
    fun deleteTask(id: String) { writableDatabase.delete("task", "id=?", arrayOf(id)) }
    fun tasks(kind: String, goal: String? = null): List<TaskItem> {
        val out = ArrayList<TaskItem>()
        val sql = "SELECT id,kind,goal,title,status,result,idx,updated FROM task WHERE kind=?" + (if (goal != null) " AND goal=?" else "") + " ORDER BY goal, idx, updated"
        readableDatabase.rawQuery(sql, if (goal != null) arrayOf(kind, goal) else arrayOf(kind)).use {
            while (it.moveToNext()) out += TaskItem(it.getString(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4), it.getString(5), it.getInt(6), it.getLong(7))
        }
        return out
    }

    // ---------- Atividade ----------
    fun log(text: String) {
        val cv = ContentValues().apply { put("ts", now()); put("text", text) }
        writableDatabase.insert("activity", null, cv)
    }
    fun activity(limit: Int = 100): List<Act> {
        val out = ArrayList<Act>()
        readableDatabase.rawQuery("SELECT ts,text FROM activity ORDER BY id DESC LIMIT $limit", null).use { while (it.moveToNext()) out += Act(it.getLong(0), it.getString(1)) }
        return out
    }

    // ---------- Fila de sincronização ----------
    fun enqueue(itemId: String, kind: String, payload: String) {
        val base = readableDatabase.rawQuery("SELECT hash FROM synced WHERE itemId=?", arrayOf(itemId)).use { if (it.moveToFirst()) it.getString(0) else "" }
        writableDatabase.execSQL("DELETE FROM queue WHERE itemId=?", arrayOf<Any>(itemId))   // mantém só a versão mais recente
        val cv = ContentValues().apply { put("itemId", itemId); put("kind", kind); put("payload", payload); put("hash", sha256(payload)); put("baseHash", base); put("ts", now()) }
        writableDatabase.insert("queue", null, cv)
        SyncScheduler.schedule(ctx)
    }
    fun pending(limit: Int = 50): List<QItem> {
        val out = ArrayList<QItem>()
        readableDatabase.rawQuery("SELECT id,itemId,kind,payload,hash,baseHash FROM queue ORDER BY id LIMIT $limit", null).use {
            while (it.moveToNext()) out += QItem(it.getLong(0), it.getString(1), it.getString(2), it.getString(3), it.getString(4), it.getString(5))
        }
        return out
    }
    fun pendingCount(): Int = readableDatabase.rawQuery("SELECT COUNT(*) FROM queue", null).use { it.moveToFirst(); it.getInt(0) }
    fun isPending(itemId: String): Boolean = readableDatabase.rawQuery("SELECT 1 FROM queue WHERE itemId=?", arrayOf(itemId)).use { it.moveToFirst() }
    /** Só remove da fila DEPOIS da confirmação do servidor; se o item mudou nesse meio-tempo, ele permanece. */
    fun ack(q: QItem) {
        writableDatabase.execSQL("DELETE FROM queue WHERE id=? AND hash=?", arrayOf<Any>(q.rowId, q.hash))
        writableDatabase.execSQL("INSERT OR REPLACE INTO synced(itemId,hash) VALUES(?,?)", arrayOf<Any>(q.itemId, q.hash))
    }
    fun markSynced(itemId: String, hash: String) { writableDatabase.execSQL("INSERT OR REPLACE INTO synced(itemId,hash) VALUES(?,?)", arrayOf<Any>(itemId, hash)) }

    fun syncedHash(itemId: String): String? = readableDatabase.rawQuery("SELECT hash FROM synced WHERE itemId=?", arrayOf(itemId)).use { if (it.moveToFirst()) it.getString(0) else null }
    /** Aplica uma memória vinda do servidor SEM re-enfileirar. */
    fun applyRemoteMemory(id: String, category: String, content: String, updated: Long, deleted: Boolean) {
        val cv = ContentValues().apply { put("id", id); put("category", category); put("content", content); put("updated", updated); put("deleted", if (deleted) 1 else 0) }
        writableDatabase.insertWithOnConflict("memory", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }
}
