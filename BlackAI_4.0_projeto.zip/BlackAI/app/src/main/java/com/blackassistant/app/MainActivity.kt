package com.blackassistant.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        SyncScheduler.periodic(this)
        setContent { BlackTheme { App(speak = { tts?.speak(it.take(3000), TextToSpeech.QUEUE_FLUSH, null, "black_reply") }) } }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "BR")
    }
    override fun onDestroy() { tts?.shutdown(); LocalEngine.unload(); super.onDestroy() }
}
