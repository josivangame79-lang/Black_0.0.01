package com.blackassistant.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

object Net {
    val client: OkHttpClient = OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(200, TimeUnit.SECONDS).callTimeout(220, TimeUnit.SECONDS).build()
    private fun caps(ctx: Context): NetworkCapabilities? {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.getNetworkCapabilities(cm.activeNetwork)
    }
    fun online(ctx: Context) = caps(ctx)?.let { it.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && it.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) } == true
    fun onWifi(ctx: Context) = online(ctx) && caps(ctx)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
    /** HTTPS obrigatório; HTTP só para emulador/localhost. */
    fun urlOk(u: String) = u.startsWith("https://") || u.startsWith("http://10.0.2.2") || u.startsWith("http://localhost")
}

/** Cliente do BLACK CLOUD (servidor próprio). Autenticação por token Bearer. */
class Cloud(private val prefs: Prefs) {
    fun call(method: String, path: String, body: JSONObject? = null): JSONObject {
        val base = prefs.serverUrl.trimEnd('/')
        require(base.isNotBlank() && prefs.token.isNotBlank()) { "Configure servidor e token em Conectividade." }
        require(Net.urlOk(base)) { "Use um endereço HTTPS para o servidor." }
        val b = Request.Builder().url("$base/$path").header("Authorization", "Bearer ${prefs.token}")
        if (method == "POST") b.post((body ?: JSONObject()).toString().toRequestBody("application/json".toMediaType())) else b.get()
        Net.client.newCall(b.build()).execute().use { r ->
            val raw = r.body?.string().orEmpty()
            val j = runCatching { JSONObject(raw) }.getOrNull()
            if (!r.isSuccessful) error(j?.optString("error")?.takeIf { it.isNotBlank() } ?: "HTTP ${r.code}")
            return j ?: JSONObject()
        }
    }
    fun post(path: String, body: JSONObject) = call("POST", path, body)
}

/** Motor local: MediaPipe LLM Inference (executa o modelo no aparelho, sem internet). */
object LocalEngine {
    private var llm: LlmInference? = null
    private var loaded: String? = null
    @Synchronized fun generate(ctx: Context, path: String, prompt: String): String {
        if (loaded != path) {
            unload()
            val o = LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(1024).build()
            llm = LlmInference.createFromOptions(ctx.applicationContext, o)
            loaded = path
        }
        return llm!!.generateResponse(prompt)
    }
    @Synchronized fun unload() { runCatching { llm?.close() }; llm = null; loaded = null }

    fun prompt(modelFile: String, system: String, history: List<Pair<String, String>>, user: String): String {
        val turns = history + ("user" to user)
        val sb = StringBuilder()
        if (modelFile.lowercase().contains("gemma")) {
            turns.forEachIndexed { i, (role, text) ->
                val content = if (i == 0 && role == "user") "$system\n\n$text" else text
                sb.append("<start_of_turn>").append(if (role == "user") "user" else "model").append('\n').append(content).append("<end_of_turn>\n")
            }
            sb.append("<start_of_turn>model\n")
        } else { // ChatML (Qwen e similares)
            sb.append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
            turns.forEach { (role, text) -> sb.append("<|im_start|>").append(role).append('\n').append(text).append("<|im_end|>\n") }
            sb.append("<|im_start|>assistant\n")
        }
        return sb.toString()
    }
}

data class Reply(val text: String, val via: String)

/** Roteador híbrido: escolhe local ou nuvem (automático ou manual) e faz fallback entre eles. */
class Brain(private val ctx: Context) {
    private val prefs = Prefs(ctx)
    private val db = Db.get(ctx)
    private val cloud = Cloud(prefs)

    fun localModelFile(): File? = prefs.localModel.takeIf { it.isNotBlank() }?.let { File(ModelStore.dir(ctx), it) }?.takeIf { it.exists() }

    fun systemPrompt(userText: String): String {
        val mem = db.relevantMemories(userText)
        return "Você é BLACK, assistente pessoal inteligente. Responda em português do Brasil, de forma clara e honesta. " +
            "Não afirme ter feito ações que não fez." +
            if (mem.isNotEmpty()) "\nMemórias do usuário (use se relevante):\n" + mem.joinToString("\n") { "- [${it.category}] ${it.content}" } else ""
    }

    /** "lembre-se que ..." salva direto na memória local (funciona offline, sem LLM). */
    fun tryMemoryCommand(text: String): String? {
        val m = Regex("^\\s*(lembre-?se|lembra|guarde|memorize|anote)\\s*(que|:)?\\s+(.+)$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(text) ?: return null
        val content = m.groupValues[3].trim()
        db.saveMemory("geral", content)
        return "Guardei na memória: \"$content\""
    }

    suspend fun ask(
        userText: String, history: List<Pair<String, String>> = emptyList(), imageB64: String? = null,
        mode: String? = null, system: String? = null
    ): Reply = withContext(Dispatchers.IO) {
        val m = mode ?: prefs.mode
        val sys = system ?: systemPrompt(userText)
        val complex = userText.length > 600 || Regex("(?i)pesquis|compil|apk|refator|analis[ae].*(documento|projeto|c[oó]digo)").containsMatchIn(userText)
        val order = when {
            imageB64 != null -> listOf("cloud")
            m == "local" -> listOf("local")
            m == "cloud" -> listOf("cloud")
            complex -> listOf("cloud", "local")
            else -> listOf("local", "cloud")
        }
        val problems = ArrayList<String>()
        for (route in order) {
            try {
                if (route == "local") {
                    val f = localModelFile() ?: run { problems += "nenhum modelo local instalado/selecionado"; null } ?: continue
                    val out = LocalEngine.generate(ctx, f.absolutePath, LocalEngine.prompt(f.name, sys, history, userText)).trim()
                    if (out.isNotBlank()) return@withContext Reply(out, "local")
                    problems += "modelo local devolveu resposta vazia"
                } else {
                    if (!prefs.cloudConfigured) { problems += "servidor não configurado"; continue }
                    if (!Net.online(ctx)) { problems += "sem internet"; continue }
                    val msgs = JSONArray(); history.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
                    val body = JSONObject().put("system", sys).put("messages", msgs).put("message", userText)
                    if (imageB64 != null) body.put("imageBase64", imageB64)
                    return@withContext Reply(cloud.post("chat", body).optString("reply"), "nuvem")
                }
            } catch (e: Throwable) { problems += "$route: ${e.message ?: e.javaClass.simpleName}" }
        }
        val extra = if (imageB64 != null) " (análise de imagem exige o BLACK CLOUD com modelo de visão; ainda não há modelo multimodal local)" else ""
        error("Não consegui responder$extra. Motivos: ${problems.joinToString("; ")}")
    }
}
