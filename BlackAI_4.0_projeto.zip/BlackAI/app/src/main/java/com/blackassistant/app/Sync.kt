package com.blackassistant.app

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Sincronização AUTOMÁTICA SOMENTE POR WI-FI: restrição UNMETERED + verificação extra de transporte Wi-Fi. */
class SyncWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val c = applicationContext
        val prefs = Prefs(c); val db = Db.get(c)
        if (!prefs.cloudConfigured) return@withContext Result.success()
        if (!Net.onWifi(c)) return@withContext Result.retry()   // sem Wi-Fi: nada é enviado; o app segue offline
        try {
            val cloud = Cloud(prefs)
            while (true) {
                val batch = db.pending(50)
                if (batch.isEmpty()) break
                val items = JSONArray()
                batch.forEach { items.put(JSONObject().put("id", it.itemId).put("kind", it.kind).put("payload", it.payload).put("hash", it.hash).put("baseHash", it.baseHash)) }
                val r = cloud.post("sync/push", JSONObject().put("device", prefs.deviceId).put("items", items))
                val ack = r.getJSONArray("ack")
                val ok = HashSet<String>()
                for (i in 0 until ack.length()) {
                    val a = ack.getJSONObject(i); ok += a.getString("id")
                    if (a.optString("status") == "conflict-preserved") db.log("Conflito em ${a.getString("id")}: versão anterior do servidor preservada.")
                }
                batch.filter { it.itemId in ok }.forEach { db.ack(it) }   // só remove da fila após confirmação
                if (batch.none { it.itemId in ok }) return@withContext Result.retry()
            }
            val pull = cloud.post("sync/pull", JSONObject().put("device", prefs.deviceId).put("since", prefs.lastPull)).getJSONArray("items")
            var maxTs = prefs.lastPull
            for (i in 0 until pull.length()) {
                val it = pull.getJSONObject(i)
                maxTs = maxOf(maxTs, it.optLong("serverTs"))
                if (it.optString("kind") == "memory") mergeMemory(db, it)
            }
            prefs.lastPull = maxTs
            prefs.lastSync = System.currentTimeMillis()
            db.log("Sincronização concluída (Wi-Fi).")
            Result.success()
        } catch (e: Exception) {
            db.log("Sincronização falhou: ${e.message}")
            Result.retry()
        }
    }

    /** Nunca perde dados locais: se há alteração local pendente, a versão remota vira uma memória "conflito". */
    private fun mergeMemory(db: Db, it: JSONObject) {
        val itemId = it.getString("id"); val hash = it.getString("hash")
        if (db.syncedHash(itemId) == hash) return
        val p = JSONObject(it.getString("payload"))
        val id = p.getString("id"); val local = db.memory(id)
        if (db.isPending(itemId)) {
            if (!p.optBoolean("deleted") && local?.content != p.getString("content")) db.saveMemory("conflito", p.getString("content"))
            return
        }
        db.applyRemoteMemory(id, p.getString("category"), p.optString("content"), p.optLong("updated"), p.optBoolean("deleted"))
        db.markSynced(itemId, hash)
    }
}

object SyncScheduler {
    private val wifiOnly = Constraints.Builder().setRequiredNetworkType(NetworkType.UNMETERED).build()
    fun schedule(ctx: Context) {
        val wm = WorkManager.getInstance(ctx)
        wm.enqueueUniqueWork("black-sync", ExistingWorkPolicy.KEEP, OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(wifiOnly).build())
    }
    fun periodic(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("black-sync-periodic", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).setConstraints(wifiOnly).build())
    }
}
