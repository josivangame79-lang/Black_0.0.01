package com.blackassistant.app

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject

/** Gerenciador de arquivos restrito à pasta que o usuário autorizou (Storage Access Framework). */
class FileStore(private val ctx: Context, private val prefs: Prefs, private val db: Db) {
    companion object { const val BK = ".black_backups" }
    data class Change(val rel: String, val file: DocumentFile, val backup: DocumentFile?)
    private val cr get() = ctx.contentResolver

    fun root(): DocumentFile? = prefs.folderUri.takeIf { it.isNotBlank() }?.let { DocumentFile.fromTreeUri(ctx, Uri.parse(it)) }?.takeIf { it.canRead() }
    fun list(d: DocumentFile): List<DocumentFile> = d.listFiles().filter { it.name != BK }.sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase() ?: "" }))
    fun read(f: DocumentFile, max: Int = 1_000_000): String = cr.openInputStream(f.uri)?.use { s ->
        val b = s.readBytes(); String(if (b.size > max) b.copyOf(max) else b, Charsets.UTF_8)
    } ?: ""

    private fun backupDir(): DocumentFile? { val r = root() ?: return null; return r.findFile(BK) ?: r.createDirectory(BK) }
    fun backup(f: DocumentFile): DocumentFile? {
        val b = backupDir()?.createFile("application/octet-stream", "${f.name}.${System.currentTimeMillis()}.bak") ?: return null
        cr.openInputStream(f.uri)?.use { i -> cr.openOutputStream(b.uri, "wt")?.use { o -> i.copyTo(o) } }
        return b
    }

    fun write(dir: DocumentFile, name: String, text: String, rel: String = name): Change {
        require(name.isNotBlank() && !name.contains('/') && name != ".." && name != BK) { "nome inválido: $name" }
        val existing = dir.findFile(name)
        val bk = existing?.takeIf { it.isFile }?.let { backup(it) }          // backup ANTES de alterar
        val f = existing ?: dir.createFile("application/octet-stream", name) ?: error("não foi possível criar $name")
        cr.openOutputStream(f.uri, "wt")?.use { it.write(text.toByteArray()) } ?: error("sem permissão de escrita em $name")
        if (text.length < 500_000) db.enqueue("file-" + sha256(rel).take(40), "file", JSONObject().put("path", rel).put("content", text).toString())
        db.log("Arquivo gravado: $rel" + if (bk != null) " (backup criado)" else "")
        return Change(rel, f, bk)
    }
    fun writePath(rel: String, text: String): Change {
        val parts = rel.replace('\\', '/').split('/').filter { it.isNotBlank() }
        require(parts.isNotEmpty() && parts.none { it == ".." || it == BK }) { "caminho inválido: $rel" }
        var dir = root() ?: error("Nenhuma pasta autorizada")
        for (p in parts.dropLast(1)) dir = dir.findFile(p) ?: dir.createDirectory(p) ?: error("não foi possível criar a pasta $p")
        return write(dir, parts.last(), text, parts.joinToString("/"))
    }
    fun mkdir(dir: DocumentFile, name: String): DocumentFile? {
        require(name.isNotBlank() && !name.contains('/') && name != "..") { "nome inválido" }
        return dir.findFile(name) ?: dir.createDirectory(name)
    }
    fun rename(f: DocumentFile, newName: String): Boolean {
        require(newName.isNotBlank() && !newName.contains('/')) { "nome inválido" }
        val ok = f.renameTo(newName); if (ok) db.log("Renomeado: ${f.name} -> $newName"); return ok
    }
    fun versions(name: String): List<DocumentFile> = backupDir()?.listFiles()?.filter { it.name?.startsWith("$name.") == true }?.sortedByDescending { it.name } ?: emptyList()
    fun restore(bk: DocumentFile, target: DocumentFile) {
        backup(target)
        cr.openInputStream(bk.uri)?.use { i -> cr.openOutputStream(target.uri, "wt")?.use { o -> i.copyTo(o) } }
        db.log("Versão restaurada em ${target.name}")
    }
    fun rollback(c: Change) { if (c.backup != null) restore(c.backup, c.file) else c.file.delete(); db.log("Reversão aplicada: ${c.rel}") }

    /** Texto dos arquivos da pasta autorizada (para enviar ao sandbox do servidor). Limites: 60 arquivos, 100 KB cada, 500 KB no total. */
    fun collectText(): Map<String, String> {
        val out = LinkedHashMap<String, String>(); var total = 0
        fun walk(d: DocumentFile, prefix: String) {
            for (f in list(d)) {
                if (out.size >= 60 || total > 500_000) return
                val n = f.name ?: continue
                if (f.isDirectory) { if (n != "build" && n != "node_modules" && !n.startsWith(".")) walk(f, "$prefix$n/") }
                else if (f.length() in 1..100_000 && Regex(".*\\.(kt|java|js|mjs|ts|py|json|md|txt|xml|gradle|kts|html|css|sh|properties)$").matches(n)) {
                    val t = read(f); total += t.length; out["$prefix$n"] = t
                }
            }
        }
        root()?.let { walk(it, "") }
        return out
    }

    fun diff(a: String, b: String): String {
        val x = a.lines(); val y = b.lines()
        if (x.size > 1500 || y.size > 1500) return "Arquivos grandes demais para comparar."
        val dp = Array(x.size + 1) { IntArray(y.size + 1) }
        for (i in x.indices.reversed()) for (j in y.indices.reversed()) dp[i][j] = if (x[i] == y[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])
        val sb = StringBuilder(); var i = 0; var j = 0
        while (i < x.size && j < y.size) {
            if (x[i] == y[j]) { i++; j++ }
            else if (dp[i + 1][j] >= dp[i][j + 1]) { sb.append("- ").append(x[i]).append('\n'); i++ }
            else { sb.append("+ ").append(y[j]).append('\n'); j++ }
        }
        while (i < x.size) { sb.append("- ").append(x[i++]).append('\n') }
        while (j < y.size) { sb.append("+ ").append(y[j++]).append('\n') }
        return sb.toString().ifBlank { "Sem diferenças." }
    }
}
