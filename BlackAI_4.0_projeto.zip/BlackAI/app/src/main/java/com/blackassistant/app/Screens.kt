@file:OptIn(ExperimentalMaterial3Api::class)

package com.blackassistant.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.RecognizerIntent
import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.text.DateFormat
import java.util.Date

// ---------------------------------------------------------------- utilidades
fun imageToB64(ctx: Context, uri: Uri): String {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var s = 1; while (maxOf(bounds.outWidth, bounds.outHeight) / s > 1280) s *= 2
    val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) } ?: error("Imagem ilegível")
    val bo = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 80, bo)
    return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
}
fun fmtMb(b: Long) = if (b >= 1L shl 30) "%.2f GB".format(b / 1073741824.0) else "%d MB".format(b / 1048576)
fun fmtTime(t: Long) = if (t == 0L) "nunca" else DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(t))

@Composable fun Sub(text: String, modifier: Modifier = Modifier) = Text(text, modifier, color = Dim, fontSize = 12.sp)
@Composable fun H(text: String) = Text(text, color = Txt, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 4.dp))
@Composable fun Btn(text: String, enabled: Boolean = true, onClick: () -> Unit) =
    Button(onClick, enabled = enabled, colors = ButtonDefaults.buttonColors(containerColor = Violet), shape = RoundedCornerShape(14.dp)) { Text(text) }
@Composable fun Field(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, secret: Boolean = false, lines: Int = 1) =
    OutlinedTextField(value, onChange, modifier.fillMaxWidth(), label = { Text(label) }, maxLines = lines, singleLine = lines == 1,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None)

@Composable
fun Page(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = Txt) }
            Text(title, color = Txt, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxSize().padding(horizontal = 14.dp), content = content)
    }
}

// ---------------------------------------------------------------- raiz
@Composable
fun App(speak: (String) -> Unit) {
    var screen by rememberSaveable { mutableStateOf("splash") }
    BackHandler(enabled = screen != "splash" && screen != "home") { screen = "home" }
    Surface(color = Bg, contentColor = Txt, modifier = Modifier.fillMaxSize()) {
        val back = { screen = "home" }
        when (screen) {
            "splash" -> Splash { screen = "home" }
            "home" -> Home { screen = it }
            "chat" -> ChatScreen(speak, back)
            "memory" -> MemoryScreen(back)
            "files" -> FilesScreen(back)
            "tasks" -> TasksScreen(back)
            "agent" -> AgentScreen(back)
            "models" -> ModelsScreen(back)
            "settings" -> SettingsScreen(back)
            "sync" -> SyncScreen(back)
        }
    }
}

// ---------------------------------------------------------------- 1. Inicialização
@Composable
fun Splash(done: () -> Unit) {
    val t = rememberInfiniteTransition(label = "glow")
    val a by t.animateFloat(0.35f, 1f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "a")
    LaunchedEffect(Unit) { delay(1800); done() }
    Box(Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Violet.copy(alpha = .35f * a), Bg), radius = 900f)), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.AutoAwesome, null, tint = Violet2, modifier = Modifier.size(72.dp).alpha(a))
            Spacer(Modifier.height(16.dp))
            Text("BLACK AI", color = Txt, fontSize = 38.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
            Text("4.0 • híbrido • offline + nuvem", color = Violet2, fontSize = 13.sp)
        }
    }
}

// ---------------------------------------------------------------- 2. Painel
@Composable
fun Home(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }; val db = remember { Db.get(ctx) }
    var cloud by remember { mutableStateOf("verificando…") }
    LaunchedEffect(Unit) {
        cloud = withContext(Dispatchers.IO) {
            if (!prefs.cloudConfigured) "não configurado"
            else runCatching { Cloud(prefs).call("GET", "health"); "online" }.getOrElse { "indisponível" }
        }
    }
    val local = prefs.localModel.ifBlank { "nenhum" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("BLACK AI", color = Txt, fontSize = 26.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        GlowCard(Modifier.fillMaxWidth(), onClick = { go("chat") }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, tint = Violet2, modifier = Modifier.size(34.dp)); Spacer(Modifier.width(12.dp))
                Column { Text("Assistente IA", color = Txt, fontWeight = FontWeight.SemiBold); Sub("Toque para conversar") }
            }
        }
        GlowCard(Modifier.fillMaxWidth()) {
            H("Estado")
            Sub("Modo: ${prefs.mode} • Modelo local: $local")
            Sub("Servidor: $cloud • Fila de sync: ${db.pendingCount()} • Última sync: ${fmtTime(prefs.lastSync)}")
        }
        val items = listOf(
            Triple("memory", "Memória", Icons.Default.Psychology), Triple("files", "Arquivos", Icons.Default.Folder),
            Triple("tasks", "Tarefas", Icons.Default.Checklist), Triple("agent", "Autonomia", Icons.Default.SmartToy),
            Triple("models", "Modelos de IA", Icons.Default.Memory), Triple("sync", "Conectividade", Icons.Default.Sync),
            Triple("settings", "Configurações", Icons.Default.Settings), Triple("chat", "Conversa", Icons.Default.Chat)
        )
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (k, n, ic) -> GlowCard(Modifier.weight(1f), onClick = { go(k) }) { Icon(ic, null, tint = Violet2); Spacer(Modifier.height(8.dp)); Text(n, color = Txt) } }
            }
        }
    }
}

// ---------------------------------------------------------------- 3. Conversa
@Composable
fun ChatScreen(speak: (String) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val db = remember { Db.get(ctx) }; val prefs = remember { Prefs(ctx) }; val brain = remember { Brain(ctx) }
    var msgs by remember { mutableStateOf(db.chat()) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var image by remember { mutableStateOf<Uri?>(null) }
    var doc by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableStateOf(prefs.mode) }
    val list = rememberLazyListState()
    val pickImg = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { image = it }
    val pickDoc = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) scope.launch {
            doc = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(uri)?.use { String(it.readBytes().take(20000).toByteArray()) } }.getOrNull() }
        }
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input = it }
    }
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.scrollToItem(msgs.size - 1) }

    fun send() {
        val text = input.trim()
        if ((text.isEmpty() && image == null) || busy) return
        val img = image; val d = doc
        input = ""; image = null; doc = null; busy = true
        scope.launch {
            try {
                val reply = withContext(Dispatchers.IO) {
                    val hist = db.chat(12).map { it.role to it.text }
                    val shown = text.ifEmpty { "Analise esta imagem." }
                    db.addChat("user", shown + if (d != null) "\n📎 (documento anexado)" else "")
                    withContext(Dispatchers.Main) { msgs = db.chat() }
                    brain.tryMemoryCommand(text)?.let { Reply(it, "memória local") }
                        ?: brain.ask(if (d != null) "$shown\n\nDocumento:\n$d" else shown, hist, img?.let { imageToB64(ctx, it) }, mode)
                }
                withContext(Dispatchers.IO) { db.addChat("assistant", reply.text, reply.via) }
                if (prefs.speak) speak(reply.text)
            } catch (e: Throwable) {
                withContext(Dispatchers.IO) { db.addChat("assistant", "⚠️ ${e.message}", "erro") }
            } finally { msgs = db.chat(); busy = false }
        }
    }

    Page("Conversa", onBack) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("auto" to "Auto", "local" to "Local", "cloud" to "Nuvem").forEach { (k, n) ->
                FilterChip(mode == k, { mode = k; prefs.mode = k }, label = { Text(n) })
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            if (msgs.isEmpty()) item { Sub("Diga \"lembre-se que ...\" para salvar algo na memória local. Configure um modelo em Modelos de IA ou o servidor em Conectividade.") }
            items(msgs) { m ->
                val mine = m.role == "user"
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
                    Surface(color = if (mine) Color(0xFF3B2A78) else CardA, shape = RoundedCornerShape(16.dp)) { Text(m.text, Modifier.padding(12.dp), color = Txt) }
                    if (!mine && m.via.isNotBlank()) Sub("via ${m.via}")
                }
            }
            if (busy) item { CircularProgressIndicator(Modifier.size(22.dp), color = Violet) }
        }
        if (image != null || doc != null) Sub(listOfNotNull(image?.let { "🖼 imagem (precisa do servidor)" }, doc?.let { "📎 documento" }).joinToString(" • "))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
            IconButton({ pickImg.launch("image/*") }) { Icon(Icons.Default.Image, "Imagem", tint = Violet2) }
            IconButton({ pickDoc.launch("text/*") }) { Icon(Icons.Default.Description, "Documento", tint = Violet2) }
            IconButton({
                val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR").putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                runCatching { voice.launch(i) }.onFailure { input = "" }
            }) { Icon(Icons.Default.Mic, "Voz", tint = Violet2) }
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Fale com o BLACK…") }, maxLines = 4)
            IconButton({ send() }, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.Send, "Enviar", tint = Violet) }
        }
    }
}

// ---------------------------------------------------------------- 4. Memória
@Composable
fun MemoryScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val db = remember { Db.get(ctx) }
    var q by remember { mutableStateOf("") }; var cat by remember { mutableStateOf<String?>(null) }
    var tick by remember { mutableIntStateOf(0) }
    var editing by remember { mutableStateOf<Mem?>(null) }; var adding by remember { mutableStateOf(false) }
    val list = remember(q, cat, tick) { db.memories(q, cat) }; val cats = remember(tick) { db.categories() }
    Page("Memória", onBack) {
        Field(q, { q = it }, "Pesquisar memórias")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(cat == null, { cat = null }, label = { Text("Todas") })
            cats.forEach { c -> FilterChip(cat == c, { cat = if (cat == c) null else c }, label = { Text(c) }) }
        }
        Row(Modifier.padding(vertical = 6.dp)) { Btn("Nova memória") { adding = true } }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { m ->
                GlowCard(Modifier.fillMaxWidth(), onClick = { editing = m }) {
                    Sub(m.category); Text(m.content, color = Txt)
                    Row { Sub(fmtTime(m.updated), Modifier.weight(1f)); Icon(Icons.Default.Delete, "Excluir", tint = Bad, modifier = Modifier.size(20.dp).clickableNoRipple { db.deleteMemory(m.id); tick++ }) }
                }
            }
            if (list.isEmpty()) item { Sub("Nenhuma memória encontrada.") }
        }
    }
    if (adding || editing != null) {
        var c by remember(editing, adding) { mutableStateOf(editing?.category ?: "geral") }
        var t by remember(editing, adding) { mutableStateOf(editing?.content ?: "") }
        AlertDialog(onDismissRequest = { adding = false; editing = null }, title = { Text(if (editing == null) "Nova memória" else "Editar memória") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Field(c, { c = it }, "Categoria"); Field(t, { t = it }, "Conteúdo", lines = 5) } },
            confirmButton = { TextButton({ if (t.isNotBlank()) { db.saveMemory(c.ifBlank { "geral" }, t.trim(), editing?.id ?: java.util.UUID.randomUUID().toString()); tick++ }; adding = false; editing = null }) { Text("Salvar") } },
            dismissButton = { TextButton({ adding = false; editing = null }) { Text("Cancelar") } })
    }
}
fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier = this.then(Modifier.clickable(indication = null, interactionSource = null, onClick = onClick))

// ---------------------------------------------------------------- 5. Arquivos
@Composable
fun FilesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val db = remember { Db.get(ctx) }; val prefs = remember { Prefs(ctx) }
    val fs = remember { FileStore(ctx, prefs, db) }
    var tick by remember { mutableIntStateOf(0) }
    var stack by remember { mutableStateOf(listOfNotNull(fs.root())) }
    var editing by remember { mutableStateOf<DocumentFile?>(null) }; var content by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf<String?>(null) }; var newIsDir by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }; var showVersions by remember { mutableStateOf(false) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            prefs.folderUri = uri.toString(); db.log("Pasta autorizada: $uri"); stack = listOfNotNull(fs.root())
        }
    }
    Page("Arquivos", onBack) {
        if (stack.isEmpty()) {
            GlowCard(Modifier.fillMaxWidth()) {
                H("Escolha a pasta que o BLACK pode acessar"); Sub("Ele só enxerga esta pasta. Dentro dela edita sem pedir confirmação a cada operação, mas sempre cria backup antes.")
                Spacer(Modifier.height(8.dp)); Btn("Escolher pasta") { pick.launch(null) }
            }
        } else {
            val cur = stack.last()
            Sub("📁 " + stack.drop(1).joinToString("/") { it.name ?: "?" }.ifEmpty { "/ (raiz autorizada: ${stack.first().name})" })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.horizontalScroll(rememberScrollState())) {
                if (stack.size > 1) OutlinedButton({ stack = stack.dropLast(1) }) { Text("Subir") }
                OutlinedButton({ newIsDir = false; newName = "" }) { Text("Novo arquivo") }
                OutlinedButton({ newIsDir = true; newName = "" }) { Text("Nova pasta") }
                OutlinedButton({ pick.launch(null) }) { Text("Trocar pasta") }
            }
            val children = remember(stack, tick) { fs.list(cur) }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
                items(children) { f ->
                    GlowCard(Modifier.fillMaxWidth(), onClick = {
                        if (f.isDirectory) stack = stack + f else { editing = f; content = fs.read(f) }
                    }) { Text((if (f.isDirectory) "📁 " else "📄 ") + (f.name ?: "?"), color = Txt); if (f.isFile) Sub(fmtMb(f.length())) }
                }
                if (children.isEmpty()) item { Sub("Pasta vazia.") }
            }
        }
    }
    newName?.let { n ->
        var v by remember(n) { mutableStateOf(n) }
        AlertDialog(onDismissRequest = { newName = null }, title = { Text(if (newIsDir) "Nova pasta" else "Novo arquivo") }, text = { Field(v, { v = it }, "Nome") },
            confirmButton = { TextButton({
                runCatching { val d = stack.last(); if (newIsDir) fs.mkdir(d, v.trim()) else fs.write(d, v.trim(), "") }.onFailure { info = it.message }
                newName = null; stack = stack.toList(); tick++
            }) { Text("Criar") } }, dismissButton = { TextButton({ newName = null }) { Text("Cancelar") } })
    }
    editing?.let { f ->
        AlertDialog(onDismissRequest = { editing = null }, title = { Text(f.name ?: "arquivo") },
            text = { Column { OutlinedTextField(content, { content = it }, Modifier.fillMaxWidth().heightIn(min = 200.dp, max = 360.dp), textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Txt)) } },
            confirmButton = { TextButton({ runCatching { fs.write(stack.last(), f.name!!, content) }.onFailure { info = it.message }; editing = null; tick++ }) { Text("Salvar") } },
            dismissButton = { Row { TextButton({ showVersions = true }) { Text("Versões") }; TextButton({ editing = null }) { Text("Fechar") } } })
    }
    if (showVersions && editing != null) {
        val f = editing!!; val vs = remember(f) { fs.versions(f.name ?: "") }
        AlertDialog(onDismissRequest = { showVersions = false }, title = { Text("Versões anteriores") },
            text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (vs.isEmpty()) Text("Nenhuma versão anterior.")
                vs.forEach { v -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtTime(v.name?.substringAfter("${f.name}.")?.substringBefore(".bak")?.toLongOrNull() ?: 0), Modifier.weight(1f), fontSize = 12.sp)
                    TextButton({ info = fs.diff(fs.read(v), content) }) { Text("Comparar") }
                    TextButton({ fs.restore(v, f); content = fs.read(f); showVersions = false; tick++ }) { Text("Restaurar") }
                } } } },
            confirmButton = { TextButton({ showVersions = false }) { Text("OK") } })
    }
    info?.let { AlertDialog(onDismissRequest = { info = null }, text = { Text(it, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.verticalScroll(rememberScrollState())) }, confirmButton = { TextButton({ info = null }) { Text("OK") } }) }
}

// ---------------------------------------------------------------- 6. Tarefas
@Composable
fun TasksScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val db = remember { Db.get(ctx) }
    var tick by remember { mutableIntStateOf(0) }; var t by remember { mutableStateOf("") }
    val list = remember(tick) { db.tasks("manual") }
    Page("Tarefas", onBack) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(t, { t = it }, "Nova tarefa", Modifier.weight(1f)); Spacer(Modifier.width(8.dp))
            Btn("Add", t.isNotBlank()) { db.addTask("manual", "", t.trim()); t = ""; tick++ }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(list) { k ->
                GlowCard(Modifier.fillMaxWidth()) { Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(k.status == "concluída", { db.updateTask(k.id, if (it) "concluída" else "pendente"); tick++ })
                    Text(k.title, Modifier.weight(1f), color = if (k.status == "concluída") Dim else Txt)
                    IconButton({ db.deleteTask(k.id); tick++ }) { Icon(Icons.Default.Delete, "Excluir", tint = Bad) }
                } }
            }
            if (list.isEmpty()) item { Sub("Sem tarefas. Para objetivos complexos, use Autonomia.") }
        }
    }
}

// ---------------------------------------------------------------- 7. Autonomia
@Composable
fun AgentScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val db = remember { Db.get(ctx) }; val prefs = remember { Prefs(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(2000); tick++ } }
    var goal by remember { mutableStateOf("") }; var writes by remember { mutableStateOf(prefs.agentWrites) }
    var testCmd by remember { mutableStateOf(prefs.testCommand) }; var sbCmd by remember { mutableStateOf("") }; var sbOut by remember { mutableStateOf("") }
    val tasks = remember(tick) { db.tasks("agent") }; val acts = remember(tick) { db.activity(25) }
    Page("Autonomia (Nível 3)", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlowCard(Modifier.fillMaxWidth()) {
                H("Novo objetivo"); Field(goal, { goal = it }, "O que o agente deve fazer?", lines = 3)
                Spacer(Modifier.height(6.dp)); Btn("Iniciar agente", goal.isNotBlank()) { startAgent(ctx, goal.trim()); goal = "" }
                Sub("Roda em segundo plano via WorkManager (o Android limita a ~10 min por execução; use Retomar se parar).")
            }
            GlowCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("Permitir que o agente grave arquivos", color = Txt); Sub("Somente na pasta autorizada, sempre com backup") }
                    Switch(writes, { writes = it; prefs.agentWrites = it }) }
                Spacer(Modifier.height(6.dp)); Field(testCmd, { testCmd = it; prefs.testCommand = it }, "Comando de teste no servidor (ex.: node --check app.js)")
                Sub("Se definido: após gravar, roda no sandbox; se falhar, as alterações são revertidas.")
            }
            H("Tarefas do agente")
            tasks.groupBy { it.goal }.forEach { (g, ts) ->
                GlowCard(Modifier.fillMaxWidth()) {
                    Text(g, color = Violet2, fontWeight = FontWeight.SemiBold)
                    ts.forEach { k -> Text((when (k.status) { "concluída" -> "✅ "; "erro" -> "❌ "; "executando" -> "⏳ "; else -> "⬜ " }) + k.title, color = Txt, fontSize = 13.sp) }
                    if (ts.any { it.status != "concluída" }) { Spacer(Modifier.height(6.dp)); OutlinedButton({ startAgent(ctx, g); ts.filter { it.status == "erro" }.forEach { db.updateTask(it.id, "pendente") } }) { Text("Retomar") } }
                }
            }
            H("Sandbox no servidor")
            Field(sbCmd, { sbCmd = it }, "Comando (roda isolado, sem rede, nos arquivos da pasta autorizada)")
            Btn("Executar", sbCmd.isNotBlank()) { scope.launch { sbOut = "executando…"; sbOut = withContext(Dispatchers.IO) { runCatching { Agent(ctx).sandbox(sbCmd).let { "exit=${it.optInt("exitCode")}\n${it.optString("stdout")}\n${it.optString("stderr")}" } }.getOrElse { "Erro: ${it.message}" } } } }
            if (sbOut.isNotBlank()) Text(sbOut, color = Txt, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            H("Histórico de atividades")
            acts.forEach { Sub("${fmtTime(it.ts)} — ${it.text}") }
        }
    }
}

// ---------------------------------------------------------------- 8. Modelos de IA
@Composable
fun ModelsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val prefs = remember { Prefs(ctx) }
    var tick by remember { mutableIntStateOf(0) }
    val installed = remember(tick) { ModelStore.installed(ctx) }
    val ram = remember { ModelStore.totalRamMb(ctx) }
    var url by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }
    var probe by remember { mutableStateOf("") }; var prog by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null && name.matches(Regex("[A-Za-z0-9._-]{3,100}"))) scope.launch {
            prog = "copiando…"; prog = withContext(Dispatchers.IO) { runCatching { ModelStore.importFrom(ctx, uri, name); "importado" }.getOrElse { "Erro: ${it.message}" } }; tick++
        } else prog = "Informe antes um nome de arquivo válido (ex.: modelo.task)."
    }
    Page("Modelos de IA", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlowCard(Modifier.fillMaxWidth()) {
                H("Seu aparelho"); Sub("RAM: $ram MB • Livre: ${fmtMb(ModelStore.freeBytes(ctx))} • Modelos: ${fmtMb(ModelStore.usedBytes(ctx))}")
                Sub("ABI: ${android.os.Build.SUPPORTED_ABIS.joinToString()}"); Sub(ModelStore.recommendation(ram))
            }
            H("Instalados")
            installed.forEach { m ->
                GlowCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(prefs.localModel == m.name, { prefs.localModel = m.name; LocalEngine.unload(); tick++ })
                        Column(Modifier.weight(1f)) { Text(m.name, color = Txt, fontSize = 13.sp); Sub("${fmtMb(m.bytes)} • ${ModelStore.compat(ctx, m.bytes)}") }
                        IconButton({ if (prefs.localModel == m.name) { prefs.localModel = ""; LocalEngine.unload() }; ModelStore.delete(ctx, m.name); tick++ }) { Icon(Icons.Default.Delete, "Excluir", tint = Bad) }
                    }
                }
            }
            if (installed.isEmpty()) Sub("Nenhum modelo instalado. O app continua funcionando no modo nuvem.")
            H("Adicionar modelo")
            Sub("Formato: .task / .bin do MediaPipe LLM (ex.: Qwen2.5 ou Gemma quantizados). Veja o README para onde obter, licenças e tamanhos.")
            Field(url, { url = it }, "URL HTTPS do modelo"); Field(name, { name = it }, "Nome do arquivo (ex.: qwen2.5-1.5b.task)")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ scope.launch { probe = "consultando…"; probe = withContext(Dispatchers.IO) { runCatching { val s = ModelStore.probeSize(url); if (s > 0) "Tamanho: ${fmtMb(s)}\n${ModelStore.compat(ctx, s)}" else "Servidor não informou o tamanho." }.getOrElse { "Erro: ${it.message}" } } } }, enabled = url.startsWith("https://")) { Text("Ver tamanho") }
                OutlinedButton({ import.launch(arrayOf("*/*")) }) { Text("Importar arquivo") }
            }
            if (probe.isNotBlank()) Sub(probe)
            Btn("Baixar (somente Wi-Fi)", !busy && url.startsWith("https://") && name.isNotBlank()) {
                if (!Net.onWifi(ctx)) prog = "Conecte-se a uma rede Wi-Fi para baixar modelos."
                else { busy = true; scope.launch { prog = withContext(Dispatchers.IO) { runCatching {
                    ModelStore.download(ctx, url, name) { d, t -> prog = if (t > 0) "baixando ${fmtMb(d)} / ${fmtMb(t)}" else "baixando ${fmtMb(d)}" }; "concluído"
                }.getOrElse { "Erro: ${it.message}" } }; busy = false; tick++ } }
            }
            if (prog.isNotBlank()) Sub(prog)
        }
    }
}

// ---------------------------------------------------------------- 9. Configurações
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val prefs = remember { Prefs(ctx) }; val db = remember { Db.get(ctx) }
    var mode by remember { mutableStateOf(prefs.mode) }; var speak by remember { mutableStateOf(prefs.speak) }; var msg by remember { mutableStateOf("") }
    Page("Configurações", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlowCard(Modifier.fillMaxWidth()) {
                H("Modo de funcionamento")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("auto" to "Automático", "local" to "Só local", "cloud" to "Só nuvem").forEach { (k, n) -> FilterChip(mode == k, { mode = k; prefs.mode = k }, label = { Text(n) }) } }
                Sub("Automático: perguntas simples no aparelho; tarefas pesadas e imagens no servidor, com fallback entre os dois.")
            }
            GlowCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Ler respostas em voz alta", Modifier.weight(1f), color = Txt); Switch(speak, { speak = it; prefs.speak = it }) }
                Sub("Usa o TTS do Android (offline se a voz pt-BR estiver instalada no sistema).")
            }
            GlowCard(Modifier.fillMaxWidth()) {
                H("Dados"); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ db.clearChat(); msg = "Conversa apagada." }) { Text("Limpar conversa") }
                    OutlinedButton({ LocalEngine.unload(); msg = "Modelo descarregado da RAM." }) { Text("Liberar RAM") }
                }
                if (msg.isNotBlank()) Sub(msg)
            }
            GlowCard(Modifier.fillMaxWidth()) { H("Segurança"); Sub("Credenciais em armazenamento criptografado (Keystore). HTTPS obrigatório (HTTP só no emulador). O agente só acessa a pasta que você autorizar e nunca altera o próprio sistema."); Sub("BLACK AI 4.0") }
        }
    }
}

// ---------------------------------------------------------------- 10. Conectividade e sincronização
@Composable
fun SyncScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope(); val prefs = remember { Prefs(ctx) }; val db = remember { Db.get(ctx) }
    var url by remember { mutableStateOf(prefs.serverUrl) }; var token by remember { mutableStateOf(prefs.token) }; var status by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(2000); tick++ } }
    Page("Conectividade", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            GlowCard(Modifier.fillMaxWidth()) {
                H("BLACK CLOUD (servidor próprio)")
                Field(url, { url = it }, "URL (https://...)"); Spacer(Modifier.height(6.dp)); Field(token, { token = it }, "Token (BLACK_TOKEN do servidor)", secret = true)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("Salvar") { prefs.serverUrl = url; prefs.token = token; status = "Salvo." }
                    OutlinedButton({ prefs.serverUrl = url; prefs.token = token; scope.launch { status = "testando…"; status = withContext(Dispatchers.IO) { runCatching { Cloud(prefs).call("GET", "activity"); "Conexão e autenticação OK" }.getOrElse { "Falhou: ${it.message}" } } } }) { Text("Testar") }
                }
                if (status.isNotBlank()) Sub(status)
            }
            val pending = remember(tick) { db.pendingCount() }
            GlowCard(Modifier.fillMaxWidth()) {
                H("Sincronização"); Sub("Automática SOMENTE por Wi-Fi (fixo, não pode ser desativado).")
                Sub("Wi-Fi agora: ${if (Net.onWifi(ctx)) "sim" else "não"} • Pendentes: $pending • Última: ${fmtTime(prefs.lastSync)}")
                Sub("Tudo é salvo primeiro no celular; sem Wi-Fi o app segue offline e a fila espera.")
                Spacer(Modifier.height(6.dp))
                Btn("Sincronizar agora") {
                    status = when { !prefs.cloudConfigured -> "Configure o servidor primeiro."; !Net.onWifi(ctx) -> "Sem Wi-Fi: nada foi enviado. Fica na fila."; else -> { SyncScheduler.schedule(ctx); "Sincronização agendada." } }
                }
            }
        }
    }
}
