package com.blackassistant.app

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.StatFs
import okhttp3.Request
import java.io.File

data class Installed(val name: String, val bytes: Long)

object ModelStore {
    fun dir(ctx: Context) = File(ctx.filesDir, "models").apply { mkdirs() }
    fun installed(ctx: Context): List<Installed> = dir(ctx).listFiles()?.filter { it.isFile && !it.name.endsWith(".part") }?.map { Installed(it.name, it.length()) }?.sortedBy { it.name } ?: emptyList()
    fun usedBytes(ctx: Context) = installed(ctx).sumOf { it.bytes }
    fun freeBytes(ctx: Context) = StatFs(ctx.filesDir.path).availableBytes
    fun totalRamMb(ctx: Context): Long {
        val mi = ActivityManager.MemoryInfo(); (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi); return mi.totalMem / (1024 * 1024)
    }
    fun arm64() = Build.SUPPORTED_ABIS.contains("arm64-v8a")
    fun delete(ctx: Context, name: String) { File(dir(ctx), name).delete() }

    fun recommendation(ramMb: Long): String = when {
        ramMb < 3500 -> "Pouca RAM: use modelos de até ~0,5–1B parâmetros (arquivo ≤ ~700 MB) ou apenas o modo nuvem."
        ramMb < 6000 -> "RAM média: modelos de ~1–1,5B quantizados (arquivo ≤ ~1,6 GB)."
        ramMb < 10000 -> "RAM boa: modelos de ~2–3B quantizados (arquivo ≤ ~3 GB)."
        else -> "RAM alta: modelos de até ~4B quantizados; maiores devem ir para o BLACK CLOUD."
    }
    /** Estimativa conservadora: o modelo ocupa ~1,5x o tamanho do arquivo em RAM e só ~55% da RAM total costuma estar disponível. */
    fun compat(ctx: Context, bytes: Long): String {
        if (!arm64() && !Build.SUPPORTED_ABIS.contains("x86_64")) return "❌ Arquitetura sem suporte"
        val ramBudget = totalRamMb(ctx) * 1024L * 1024L * 55 / 100
        return when {
            bytes * 15 / 10 > ramBudget -> "⚠️ Provavelmente grande demais para a RAM deste aparelho"
            bytes * 11 / 10 > freeBytes(ctx) -> "⚠️ Espaço de armazenamento insuficiente"
            else -> "✅ Deve caber neste aparelho (não garante velocidade)"
        }
    }

    fun probeSize(url: String): Long {
        Net.client.newCall(Request.Builder().url(url).head().build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            return r.header("Content-Length")?.toLongOrNull() ?: -1L
        }
    }
    /** Bloqueante (rode em IO). Baixa para .part e só renomeia ao terminar. */
    fun download(ctx: Context, url: String, name: String, onProgress: (Long, Long) -> Unit) {
        require(url.startsWith("https://")) { "Somente HTTPS" }
        require(name.matches(Regex("[A-Za-z0-9._-]{3,100}"))) { "Nome de arquivo inválido" }
        val part = File(dir(ctx), "$name.part"); val dest = File(dir(ctx), name)
        Net.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            if (!r.isSuccessful) error("HTTP ${r.code}")
            val total = r.body?.contentLength() ?: -1L
            if (total > 0 && total * 11 / 10 > freeBytes(ctx)) error("Espaço insuficiente")
            r.body!!.byteStream().use { i -> part.outputStream().use { o ->
                val buf = ByteArray(256 * 1024); var done = 0L
                while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); done += n; onProgress(done, total) }
            } }
        }
        if (!part.renameTo(dest)) error("Falha ao finalizar o arquivo")
    }
    fun importFrom(ctx: Context, uri: Uri, name: String) {
        require(name.matches(Regex("[A-Za-z0-9._-]{3,100}"))) { "Nome de arquivo inválido" }
        ctx.contentResolver.openInputStream(uri)?.use { i -> File(dir(ctx), name).outputStream().use { o -> i.copyTo(o) } } ?: error("Não foi possível abrir o arquivo")
    }
}
