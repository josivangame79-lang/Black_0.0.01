package com.blackassistant.app

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.util.UUID

/** Credenciais e configurações em armazenamento criptografado (Android Keystore). */
class Prefs(ctx: Context) {
    private val sp = EncryptedSharedPreferences.create(
        ctx, "black_secure",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    var serverUrl: String get() = sp.getString("url", "") ?: ""; set(v) = sp.edit().putString("url", v.trim()).apply()
    var token: String get() = sp.getString("token", "") ?: ""; set(v) = sp.edit().putString("token", v.trim()).apply()
    /** auto | local | cloud */
    var mode: String get() = sp.getString("mode", "auto") ?: "auto"; set(v) = sp.edit().putString("mode", v).apply()
    var folderUri: String get() = sp.getString("folder", "") ?: ""; set(v) = sp.edit().putString("folder", v).apply()
    var localModel: String get() = sp.getString("model", "") ?: ""; set(v) = sp.edit().putString("model", v).apply()
    var speak: Boolean get() = sp.getBoolean("speak", false); set(v) = sp.edit().putBoolean("speak", v).apply()
    var agentWrites: Boolean get() = sp.getBoolean("agentWrites", false); set(v) = sp.edit().putBoolean("agentWrites", v).apply()
    var lastPull: Long get() = sp.getLong("lastPull", 0); set(v) = sp.edit().putLong("lastPull", v).apply()
    var lastSync: Long get() = sp.getLong("lastSync", 0); set(v) = sp.edit().putLong("lastSync", v).apply()
    val deviceId: String get() = sp.getString("device", null) ?: UUID.randomUUID().toString().replace("-", "").take(24).also { sp.edit().putString("device", it).apply() }
    var testCommand: String get() = sp.getString("testCmd", "") ?: ""; set(v) = sp.edit().putString("testCmd", v).apply()
    val cloudConfigured get() = serverUrl.isNotBlank() && token.isNotBlank()
}
