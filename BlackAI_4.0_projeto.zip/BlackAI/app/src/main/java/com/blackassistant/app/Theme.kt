package com.blackassistant.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val Bg = Color(0xFF07070A)
val CardA = Color(0xFF1C1C26)
val CardB = Color(0xFF111117)
val Violet = Color(0xFF8B5CF6)
val Violet2 = Color(0xFFA78BFA)
val Txt = Color(0xFFECECF3)
val Dim = Color(0xFF9A9AB0)
val Ok = Color(0xFF4ADE80)
val Warn = Color(0xFFFBBF24)
val Bad = Color(0xFFF87171)

@Composable
fun BlackTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Violet, onPrimary = Color.White, background = Bg, onBackground = Txt,
        surface = CardB, onSurface = Txt, surfaceVariant = CardA, onSurfaceVariant = Dim,
        primaryContainer = Color(0xFF3B2A78), onPrimaryContainer = Txt, secondary = Violet2
    ),
    content = content
)

@Composable
fun GlowCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    var m = modifier.clip(shape)
        .background(Brush.linearGradient(listOf(CardA, CardB)))
        .border(BorderStroke(1.dp, Brush.linearGradient(listOf(Violet.copy(alpha = .55f), Color.Transparent))), shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(m.padding(14.dp), content = content)
}
