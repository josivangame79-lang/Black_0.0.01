package com.blackassistant.app

import android.content.Context
import androidx.work.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject

/**
 * BLACK AGENT: objetivo -> plano -> tarefas -> execução -> avaliação.
 * Estado persistido no SQLite: se o app/worker for interrompido, "retomar" continua da primeira etapa não concluída.
 * Escrita de arquivos só ocorre se o usuário ligou "Permitir que o agente grave arquivos" E escolheu uma pasta.
 */
class Agent(private val ctx: Context) {
    private val prefs = Prefs(ctx); private val db = Db.get(ctx); private val brain = Brain(ctx); private val files = FileStore(ctx, prefs, db)
    private val planner = "Você é o planejador do BLACK. Responda apenas com o que foi pedido, em português."

    suspend fun plan(goal: String) {
        db.log("Planejando: $goal")
        val r = brain.ask("Objetivo: $goal\nDivida em no máximo 5 etapas curtas e verificáveis. Responda só com uma lista numerada (1. ...), uma etapa por linha.", system = planner)
        val steps = r.text.lines().mapNotNull { Regex("^\\s*\\d+[.)]\\s*(.+)$").find(it)?.groupValues?.get(1)?.trim() }.take(5).ifEmpty { listOf(goal) }
        steps.forEachIndexed { i, s -> db.addTask("agent", goal, s, "pendente", i) }
        db.log("Plano criado com ${steps.size} etapa(s) via ${r.via}.")
    }

    suspend fun run(goal: String) {
        if (db.tasks("agent", goal).isEmpty()) plan(goal)
        for (t in db.tasks("agent", goal)) {
            if (t.status == "concluída") continue
            db.updateTask(t.id, "executando"); db.log("Executando: ${t.title}")
            var ok = false; var attempt = 0
            while (attempt < 2 && !ok) {
                attempt++
                try {
                    val done = db.tasks("agent", goal).filter { it.status == "concluída" }.joinToString("\n") { "- ${it.title}: ${it.result.take(300)}" }
                    val prompt = "Objetivo geral: $goal\nEtapas já feitas:\n${done.ifBlank { "(nenhuma)" }}\n\nExecute SOMENTE esta etapa: ${t.title}\n" +
                        "Se precisar criar ou alterar um arquivo, use um bloco assim:\n```file:pasta/arquivo.ext\nconteúdo\n```\nCaso contrário responda em texto, de forma objetiva."
                    val r = withTimeoutOrNull(240_000) { brain.ask(prompt, system = planner) } ?: error("tempo esgotado (4 min)")
                    db.updateTask(t.id, "concluída", applyFileBlocks(r.text))
                    ok = true
                } catch (e: CancellationException) { db.updateTask(t.id, "pendente"); throw e }
                catch (e: Exception) { db.log("Erro na etapa '${t.title}' (tentativa $attempt): ${e.message}"); if (attempt == 2) db.updateTask(t.id, "erro", e.message ?: "erro") }
            }
            if (!ok) { db.log("Objetivo interrompido numa etapa com erro. Use Retomar."); return }
        }
        val res = db.tasks("agent", goal).joinToString("\n") { "- ${it.title}: ${it.result.take(200)}" }
        val ev = runCatching { brain.ask("Objetivo: $goal\nResultados:\n$res\nO objetivo foi cumprido? Responda em até 3 linhas, apontando falhas.", system = planner).text }.getOrElse { "avaliação indisponível: ${it.message}" }
        db.log("Avaliação final: ${ev.take(300)}")
    }

    /** Aplica blocos ```file:caminho; faz backup antes; roda o comando de teste no sandbox (se configurado) e reverte se falhar. */
    private suspend fun applyFileBlocks(text: String): String {
        val blocks = Regex("```file:([^\\n]+)\\n(.*?)```", RegexOption.DOT_MATCHES_ALL).findAll(text).toList()
        if (blocks.isEmpty()) return text
        if (!prefs.agentWrites || files.root() == null) return text + "\n\n[Arquivos NÃO gravados: ative \"Permitir que o agente grave arquivos\" e escolha uma pasta em Arquivos.]"
        val changes = ArrayList<FileStore.Change>()
        try { for (b in blocks) changes += files.writePath(b.groupValues[1].trim(), b.groupValues[2]) }
        catch (e: Exception) { changes.reversed().forEach { files.rollback(it) }; error("Falha ao gravar arquivos, tudo revertido: ${e.message}") }
        val cmd = prefs.testCommand
        if (cmd.isNotBlank()) {
            val r = runCatching { kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { sandbox(cmd) } }.getOrElse { return text + "\n\n[Arquivos gravados, mas o teste não pôde rodar: ${it.message}]" }
            if (r.optInt("exitCode") != 0) {
                changes.reversed().forEach { files.rollback(it) }
                db.log("Teste falhou (exit ${r.optInt("exitCode")}); alterações revertidas.")
                error("Teste falhou, alterações revertidas: ${r.optString("stderr").takeLast(300)}")
            }
            db.log("Teste passou após alterações do agente.")
        }
        return text + "\n\n[${changes.size} arquivo(s) gravado(s) com backup]"
    }

    /** Executa um comando no sandbox Docker do servidor, com os arquivos da pasta autorizada. */
    fun sandbox(command: String): JSONObject {
        val f = JSONObject(); files.collectText().forEach { (k, v) -> f.put(k, v) }
        db.log("Sandbox: $command")
        return Cloud(prefs).post("dev/exec", JSONObject().put("files", f).put("command", command))
    }
}

class AgentWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result {
        val goal = inputData.getString("goal") ?: return Result.failure()
        return try { Agent(applicationContext).run(goal); Result.success() }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { Db.get(applicationContext).log("Agente falhou: ${e.message}"); Result.failure() }
    }
}

fun startAgent(ctx: Context, goal: String) {
    WorkManager.getInstance(ctx).enqueueUniqueWork("agent-" + sha256(goal).take(10), ExistingWorkPolicy.KEEP,
        OneTimeWorkRequestBuilder<AgentWorker>().setInputData(workDataOf("goal" to goal)).build())
}
