plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.blackassistant.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.blackassistant.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 40
        versionName = "4.0"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }   // MediaPipe LLM: arm64 (celulares) e x86_64 (emulador)
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.work:work-runtime-ktx:2.10.0")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")
    implementation("androidx.documentfile:documentfile:1.0.1")
    // IA local offline (LLM em CPU/GPU). Aceita modelos .task/.bin (Gemma, Qwen etc. convertidos).
    implementation("com.google.mediapipe:tasks-genai:0.10.24")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
